#include "StdAfx.h"
#include "frmMemory.h"

