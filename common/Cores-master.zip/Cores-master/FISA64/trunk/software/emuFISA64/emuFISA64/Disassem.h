#pragma once

std::string Disassem(std::string, std::string, unsigned int *);
std::string Disassem(unsigned int, unsigned int, unsigned int *);