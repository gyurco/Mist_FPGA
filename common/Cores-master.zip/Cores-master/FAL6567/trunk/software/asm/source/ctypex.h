#define IsFirstIdentChar(ch)  (isalpha(ch) || (ch) == '_' || (ch) == '.')
#define IsIdentChar(ch)       (isalpha(ch) || isdigit(ch) || (ch) == '_')
