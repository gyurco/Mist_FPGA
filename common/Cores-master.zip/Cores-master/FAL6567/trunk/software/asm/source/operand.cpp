#include "Assembler.h"
#include "operand.h"

namespace RTFClasses
{
/*
	char *Operand::text()
	{
		return &theAssembler.getIBuf()->getBuf()[start];
	}
*/
}
