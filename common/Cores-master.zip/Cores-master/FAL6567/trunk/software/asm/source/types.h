#ifndef TYPES_H
#define TYPES_H

#define U64 unsigned __int64
#define U32	unsigned __int32
#define U16 unsigned __int16
#define U8 unsigned __int8

#endif
