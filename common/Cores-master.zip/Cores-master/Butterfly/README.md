﻿# Butterfly
Welcome to the Butterfly core folder. This document provides a brief intro. to the Butterfly core.
Note the docs are seriously out of date.

The Butterfly SoC is a grid computer. Processing nodes are organized into a 8x8 grid and networked
together with custom serial uarts. There are 64 processing nodes, each node contains a Butterfly16
processing core, ram, rom, and a network router. Node #$11 is boot node and has a different ROM.


