
#define THOR_FUT1     21
#define THOR_FUT2     22
#define THOR_FUT3     23
#define THOR_FUT4     24
#define THOR_FUT5     25
#define THOR_FUT6     26

