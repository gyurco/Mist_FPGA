#ifndef CTYPE_H
#define CTYPE_H

int isspace(char ch);
int isxdigit(char ch);
int isdigit(char ch);
int isalpha(char ch);
int isupper(char ch);
int islower(char ch);
int ispunct(char ch);
int isalnum(char ch);
int isgraph(char ch);
int isprint(char ch);
int iscntrl(char ch);
int tolower(char ch);
int toupper(char ch);

#endif
