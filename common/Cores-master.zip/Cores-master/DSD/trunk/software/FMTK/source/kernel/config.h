#ifndef CONFIG_H
#define CONFIG_H

#define NR_JCB  51
#define NR_TCB  256
#define NR_MBX  1024
#define NR_MSG  16384

#endif
