This directory contains code for the two-way superscalar version of the core.
At one point in time this version just barely fit into the FPGA (xc7a200), but is too big at the moment. Further refinements to the instruction set should reduce the resulting size. Hopefully it will once again fit into the FPGA.
This core has undergone some testing in the past, but there's a long way to go.
