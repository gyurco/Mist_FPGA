This directory contains code for the four-way superscalar version of the core.
The four-way version is quite large. A lot of the size increase is due to supporting more write ports on various elements like the branch predictor and register file.
The code is currently untested, awaiting the availability of a larger FPGA and supporting toolset.

